#ifndef _LINKEDLIST_H
#define _LINKEDLIST_H
#include <iostream>
#include "Point.h"
using namespace std;



template <class Templated>
struct CellNode
{
    Templated temp;
    CellNode *next;
    int colNum;
    CellNode(Templated templated, int col)
        :temp(templated),next(nullptr),colNum(col)
        {

        }
};

template <class Templated>
struct LinkedlistNode
{
    LinkedlistNode *next;
    CellNode<Templated> *down;
	int rowNum;
	LinkedlistNode(int row)
		:next(nullptr),rowNum(row),down(nullptr)
		{}
};

template <class Templated>
class Linkedlist
{
    private:
    LinkedlistNode<Templated> *head;
    public:
    Linkedlist(int rows,int cols)
    {
		head = nullptr;
        for(int i=0;i<rows;i++)
        {
            insertRow(i);
            for(int j=0;j<cols;j++)
            {
                insertColumn(i,j,rows);
            }
        }
        
    }

    void insertRow(int rowNum)
    {
        if(head==nullptr)
        {
            head= new LinkedlistNode<Templated>(rowNum);
        }
        else
        {
            LinkedlistNode<Templated> *lnode = head;
            LinkedlistNode<Templated> *prevlnode = head;
            while(lnode)
            {
                prevlnode = lnode;
                lnode = lnode->next;
            }
            lnode = new LinkedlistNode<Templated>(rowNum);
            prevlnode ->next = lnode;
        }
        
    }
    void insertColumn(int rowNum,int colNum,int rows){
        LinkedlistNode<Templated> *lnode = head;
        for(int i=0;i<rowNum;i++)
        {
            lnode = lnode->next;
        }
        //now we reached the row we wanted. Add column to here.
        if(!lnode->down)
        {
            lnode->down = new CellNode<Templated>(Point(rowNum,colNum),colNum);
        }
        else
        {
            CellNode<Templated> *cnode = lnode->down;
            CellNode<Templated> *prevcnode = lnode->down;
            while(cnode)
            {
                prevcnode = cnode;
                cnode = cnode->next;
            }
            cnode = new CellNode<Templated>(Point(rowNum,colNum),colNum);
            prevcnode ->next = cnode;
        }
        
    }

    Templated getCellObject(int row, int col)
    {
        LinkedlistNode<Templated> *lnode = head;
        for(int i=0;i<row;i++)
        {
            lnode=lnode->next;
            
        }
        CellNode<Templated> *cnode = lnode->down;
        for(int j=0;j<col;j++)
        {
            cnode = cnode->next;
        }
        return cnode->temp;
    }

    void knockdownWall(int row, int col,int direction)
    {
        LinkedlistNode<Templated> *lnode = head;
        for(int i=0;i<row;i++)
        {
            lnode=lnode->next;
            
        }
        CellNode<Templated> *cnode = lnode->down;
        for(int j=0;j<col;j++)
        {
            cnode = cnode->next;
        }
        cnode->temp.knockdownWall(direction);
    }

    bool getWall(int row,int col,int direction)
    {
        LinkedlistNode<Templated> *lnode = head;
        for(int i=0;i<row;i++)
        {
            lnode=lnode->next;
            
        }
        CellNode<Templated> *cnode = lnode->down;
        for(int j=0;j<col;j++)
        {
            cnode = cnode->next;
        }
        return cnode->temp.getWall(direction);
    }

    void visit(int row, int col)
    {
        LinkedlistNode<Templated> *lnode = head;
        for(int i=0;i<row;i++)
        {
            lnode=lnode->next;
            
        }
        CellNode<Templated> *cnode = lnode->down;
        for(int j=0;j<col;j++)
        {
            cnode = cnode->next;
        }
        cnode->temp.visit();
    }

    bool isVisited(int row, int col)
    {
        LinkedlistNode<Templated> *lnode = head;
        for(int i=0;i<row;i++)
        {
            lnode=lnode->next;
            
        }
        CellNode<Templated> *cnode = lnode->down;
        for(int j=0;j<col;j++)
        {
            cnode = cnode->next;
        }
        return cnode->temp.isVisited();
    }
	void UnVisit(int row, int col)
    {
        LinkedlistNode<Templated> *lnode = head;
        for(int i=0;i<row;i++)
        {
            lnode=lnode->next;
            
        }
        CellNode<Templated> *cnode = lnode->down;
        for(int j=0;j<col;j++)
        {
            cnode = cnode->next;
        }
        cnode->temp.unvisit();
    }
};

#endif