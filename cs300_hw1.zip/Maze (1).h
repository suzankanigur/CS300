#ifndef _MAZE_H
#define _MAZE_H

#include "randgen.h"
#include "Linkedlist.h"
#include "Stack.h"
#include <iostream>
#include <string>
#include <fstream>

using namespace std;
bool isNeighborAvailable(Point pt,int xlim, int ylim)
{
	if(!pt.isValid(xlim,ylim))
		return false;
	if(pt.isVisited())
		return false;
	return true;
}


int selectRandomNeighbor(Point pt1, Point pt2, Point pt3, Point pt4,int xlim, int ylim)
{

	if(!isNeighborAvailable(pt1,xlim,ylim) && !isNeighborAvailable(pt2,xlim,ylim) && !isNeighborAvailable(pt3,xlim,ylim) && !isNeighborAvailable(pt4,xlim,ylim))
        return 0;
    RandGen r;
    int k = r.RandInt(1, 4);
    bool ok = false;
    while(!ok)
    {
		if(k==1 && !pt1.isVisited() && pt1.isValid(xlim,ylim))
            return 1;
        else if(k==2 && !pt2.isVisited() && pt2.isValid(xlim,ylim))
            return 2;
        else if(k==3 && !pt3.isVisited() && pt3.isValid(xlim,ylim))
            return 3;
        else if(k==4 && !pt4.isVisited() && pt4.isValid(xlim,ylim))
            return 4;
        k = r.RandInt(1,4);
    }
    return 0;
}

class Maze
{
private:
    int nrows;
    int ncols;
    Linkedlist<Point> cells;
public:
    Maze(int r, int c)
        :nrows(r), ncols(c), cells(Linkedlist<Point>(r,c))
    {
        buildmaze();
    }
    void buildmaze()
    {
        Stack<Point> stack;
        int curr_visit_count = 1;
        stack.push(cells.getCellObject(0,0));
        cells.visit(0,0);
        while(curr_visit_count != nrows*ncols)
        {
            Point pt(-1,-1);
            stack.pop(pt);
            stack.push(pt);
            if(pt.isValid(nrows,ncols))
            {
                //find its neighbors
                Point topN(pt.get_x()+1,pt.get_y());
				if(topN.isValid(nrows,ncols))
					topN = cells.getCellObject(topN.get_x(),topN.get_y());
                Point leftN(pt.get_x(),pt.get_y()-1);
				if(leftN.isValid(nrows,ncols))
					leftN = cells.getCellObject(leftN.get_x(),leftN.get_y());
                Point downN(pt.get_x()-1,pt.get_y());
				if(downN.isValid(nrows,ncols))
					downN = cells.getCellObject(downN.get_x(),downN.get_y());
                Point rightN(pt.get_x(),pt.get_y()+1);
				if(rightN.isValid(nrows,ncols))
					rightN = cells.getCellObject(rightN.get_x(),rightN.get_y());
                int randomN = selectRandomNeighbor(topN,rightN,downN,leftN,nrows,ncols);
                if(randomN==0)//there is no neighbor that is unvisited, pop this point
                {
                    stack.pop(pt);
                }
                else
                {
                    //visit the cell and increment the count
                    curr_visit_count++;
                    //knock down the correct wall
                    if(randomN==1)//up neighbor
                    {
                        cells.visit(topN.get_x(),topN.get_y());
                        cells.knockdownWall(topN.get_x(),topN.get_y(),2);
                        cells.knockdownWall(pt.get_x(),pt.get_y(),0);
                        stack.push(topN);
                    }
                    else if(randomN==2)//right neighbor
                    {
                        cells.visit(rightN.get_x(),rightN.get_y());
                        cells.knockdownWall(rightN.get_x(),rightN.get_y(),3);
                        cells.knockdownWall(pt.get_x(),pt.get_y(),1);
                        stack.push(rightN);
                    }
                    else if(randomN==3)//down neighbor
                    {
                        cells.visit(downN.get_x(),downN.get_y());
                        cells.knockdownWall(downN.get_x(),downN.get_y(),0);
                        cells.knockdownWall(pt.get_x(),pt.get_y(),2);
                        stack.push(downN);
                    }
                    else if(randomN==4)//left neighbor
                    {
                        cells.visit(leftN.get_x(),leftN.get_y());
                        cells.knockdownWall(leftN.get_x(),leftN.get_y(),1);
                        cells.knockdownWall(pt.get_x(),pt.get_y(),3);
                        stack.push(leftN);
                    }
                    
                }
            }
            else
            {
                curr_visit_count = nrows * ncols;
            }
            
        }
    }

    void printMaze(string filename)
    {
        ofstream o;
        o.open(filename.c_str());
        o << ncols << " " << nrows << endl;
        for (int col = 0; col < ncols; col++)
        {
            for (int row = 0; row < nrows; row++)
            {
                o << "x=" << cells.getCellObject(row,col).get_x() ;
                o << " y=" << cells.getCellObject(row,col).get_y()  ;
                o << " l=" << cells.getWall(row,col,3)  ;
                o << " r=" << cells.getWall(row,col,1)  ;
                o << " u=" << cells.getWall(row,col,0)  ;
                o << " d=" << cells.getWall(row,col,2)  << endl;
            }
        }
        o.close();
    }
	void pathfinder(Point starting, Point ending, string filename)
    {
        for (int i = 0; i < nrows; i++)
        {
            for (int j = 0; j < ncols; j++)
            {
                cells.UnVisit(i, j);
            }
        }
        Stack<Point> stack;
        cells.visit(starting.get_x(), starting.get_y());
        stack.push(cells.getCellObject(starting.get_x(), starting.get_y()));
        int num_visited = 1;
        while (!cells.isVisited(ending.get_x(), ending.get_y()))
        {
            Point pt(-1, -1);
            stack.pop(pt);
            stack.push(pt);
            if (!pt.isValid(nrows, ncols))
            {
                cells.visit(ending.get_x(), ending.get_y());
            }
            else
            {
                Point topN(pt.get_x() + 1, pt.get_y());
                if (topN.isValid(nrows, ncols))
                    topN = cells.getCellObject(topN.get_x(), topN.get_y());
                Point leftN(pt.get_x(), pt.get_y() - 1);
                if (leftN.isValid(nrows, ncols))
                    leftN = cells.getCellObject(leftN.get_x(), leftN.get_y());
                Point downN(pt.get_x() - 1, pt.get_y());
                if (downN.isValid(nrows, ncols))
                    downN = cells.getCellObject(downN.get_x(), downN.get_y());
                Point rightN(pt.get_x(), pt.get_y() + 1);
                if (rightN.isValid(nrows, ncols))
                    rightN = cells.getCellObject(rightN.get_x(), rightN.get_y());
                Point nextCell(-1, -1);
                if (!pt.getWall(0) && isNeighborAvailable(topN,nrows,ncols))
                    nextCell = topN;
                else if (!pt.getWall(1) && isNeighborAvailable(rightN,nrows,ncols))
                    nextCell = rightN;
                else if (!pt.getWall(2) && isNeighborAvailable(downN,nrows,ncols))
                    nextCell = downN;
                else if (!pt.getWall(3) && isNeighborAvailable(leftN,nrows,ncols))
                    nextCell = leftN;
                if (!nextCell.isValid(nrows, ncols)) 
                {
                    stack.pop(pt);
                    num_visited--;
                }
                else
                {
                    cells.visit(nextCell.get_x(), nextCell.get_y());
                    stack.push(cells.getCellObject(nextCell.get_x(), nextCell.get_y()));
                    num_visited++;
                }
            }
        }
        Stack<Point> path;
        while (!stack.isEmpty())
        {
            Point pt(-1, -1);
            stack.pop(pt);
            path.push(pt);
        }

        printpath(filename, path);
    }

    void printpath(string filename, Stack<Point> path)
    {
        ofstream o;
        o.open(filename.c_str());
        Point pt(-1,-1);
        while (!path.isEmpty())
        {
            path.pop(pt);
            o << pt.get_x() << " " << pt.get_y() << endl;
        }
        o.close();
    }
};



#endif