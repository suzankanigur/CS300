#ifndef _STACK_H
#define _STACK_H
#include <iostream>
using namespace std;

template <class Templated>
struct StackNode {
	Templated temp ;
	StackNode *next;
	
	StackNode(Templated templated)
		:temp(templated),next(nullptr)
		{}
};

template <class Templated>
class Stack {
 private:
  StackNode<Templated> *top;
  
 public:
	Stack()
	{
		top=nullptr;
	}

	void push(Templated temp)
	{
		StackNode<Templated> *snode;
		snode = new StackNode<Templated>(temp);
		if (!top)
			top = snode;
		else
		{
			snode->next = top;
			top = snode;
		}
	}

	void pop(Templated & temp)
	{
		StackNode<Templated> *snode;
		if (top) 
		{
			temp = top->temp;
			snode = top->next;
			delete top;
			top = snode;
		}
	}

	bool isEmpty() const{
		return top==nullptr;
	}
};

#endif