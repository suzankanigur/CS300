#include "Maze.h"
#include <vector>
#include <iostream>
using namespace std;

string digitToStr(int digit)
{
    if(digit==0)
        return "0";
    else if(digit==1)
        return "1";
    else if(digit==2)
        return "2";
    else if(digit==3)
        return "3";
    else if(digit==4)
        return "4";
    else if(digit==5)
        return "5";
    else if(digit==6)
        return "6";
    else if(digit==7)
        return "7";
    else if(digit==8)
        return "8";
    else
        return "9";    
}
string numToStr(int num)
{
    string str="";
    while(num!=0)
    {
        str = str + digitToStr(num - num/10);
        num = num/10;
    }
    return str;
}

int main()
{
	int maznum,Rows,Columns,mazeid,x1,x2,y1,y2;
	cout << "Enter the number of mazes: " ;
	cin >> maznum;
	cout << "Enter the number of rows and columns (M and N): ";
	cin >> Rows >> Columns;
	vector <Maze> allMazes;
	for(int i=0; i< maznum; i++)
	{
		Maze mz(Columns,Rows);
		mz.printMaze("maze_"+numToStr(i+1)+".txt");
		allMazes.push_back(mz);
	}
	cout << "All mazes are generated." << endl<< endl;
	cout << "Enter a maze ID between 1 to " + numToStr(maznum) + " inclusive to find a path: ";
	cin >> mazeid;
	cout << "Enter x and y coordinates of the entry points (x,y) or (column,row): ";
	cin >> x1 >> y1;
	cout << "Enter x and y coordinates of the exit points (x,y) or (column,row): ";
	cin >> x2 >> y2;
	Point starting(y1,x1);
	Point ending(y2,x2);
	string filename= "maze_" + numToStr(mazeid) + "_path_" + numToStr(x1) + "_" +numToStr(y1) + "_" + numToStr(x2) + "_" +numToStr(y2)+".txt";
	allMazes[mazeid-1].pathfinder(starting,ending,filename);
	return 0;
}