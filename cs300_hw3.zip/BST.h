#ifndef _BST_H
#define _BST_H
#include <string>
#include <iostream>
#include <vector>
using namespace std;

template <class Type>
class BST;

struct DocumentItem              
{
    string documentName;
    int count;
    DocumentItem(string dN = "", int c = 0)
        : documentName(dN), count(c)
    {
    }
};

/*struct WordItem
{
    string word;
    vector<DocumentItem> details;
    WordItem()
    {
        word = "***not***found***";
    }
};*/

template <class Type>
class BstNode 
{
    public:
    Type key;
    Type val;
    BstNode *left;
    BstNode *right;
    int height;

    BstNode(const Type &v, const Type &k, BstNode *lt=NULL, BstNode *rt=NULL, int h = 0)
        : key(k), val(v), left(lt), right(rt), height(h) {}

    friend class BST<Type>;
};

template <class Type>
class BST
{
public:
    explicit BST(const Type & notFound)  //default constructor
        :ITEM_NOT_FOUND(notFound), root(nullptr)                    
    {
    }
	
    BST(const BST<Type> & rhs)  //Copy constructor                  
        :ITEM_NOT_FOUND(rhs.ITEM_NOT_FOUND), root(nullptr)
	{
		*this = rhs;
	}

    bool isEmpty() const                                             
    {
        return root==NULL;
    }
   
    BstNode<Key, Value>* find(Type &x)
    {
        return find(x, root);
    }
    void insert(Type &x, string dname)
    {
        insert(x,dname, root);
    }

private: 
	node<Type> * root;
	Type ITEM_NOT_FOUND;//if the element searched is not found, return this value

	const Type & elementAt(node<Type> * t) const;
	void insert(const Type & x, const Type & y, node<Type> * &t) const;
	node<Type> * find(const Type & x, node<Type> * t) const;

    BstNode<Key, Value> *root;
    BstNode<Type> *find(const Type &x, BstNode<Type> *t) const
    {
        while(t != NULL)
            if(x < t->key)
                t = t->left;
            else if(t->key < x)
                t = t->right;
            else
                return t;    // Match
        return NULL;   // No match
    }
    void insert(const Type & x, const Type & y, BstNode<Type> * &t) const
    {
		if(t == NULL)
			t = new BstNode<Type>(x, y);
		else if(x < t->key)
		{
			insert(x, y, t->left);
		}
		else if(t->key < x)
		{
			insert(x, y, t->right);
		}
		else//duplicate
			t->val = t->val + y;
		t->height = max(height(t->left), height(t->right));//height update
	}

    int height(BstNode<Type> *t) const      
    {
        if (t == NULL)
            return -1;
        return t->height;
    }
    int max(int lhs, int rhs) const
    {
        if (lhs > rhs)
            return lhs;
        return rhs;
	}
};
#endif