#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <chrono>
#include "BST.h"
#include "hash.h"
#include <vector>
#include "strutils.h"
using namespace std;

string notFound = "ITEM_NOT_FOUND";
BST<string, WordItem> tree(notFound);
HashTable<string> h_table(notFound);

void ToLower(string &s)
{
	int len = s.length();
	for(int k = 0; k < len; k++)
	{
		s[k] = tolower(s[k]);
	}
}


void process_for_a_file(string filename)
{
    ifstream ifs;
    ifs.open(filename);
    string str;
    while(ifs>>str)
    {
		ToLower(str);
		wordCheck(str);
        tree.insert(str,filename);
	}
    ifs.close();
	cout << "After preprocessing, the unique word count is " << h_table.getUnique() << ". Current load ratio is " << double(h_table.getUnique())/double(h_table.getSize()) << endl;
}

//QUERY FILE READING
bool findInVec(vector<string> vec, string key)
{
    for(int i=0;i<vec.size();i++)
    {
        if(vec[i]==key)
            return true;
    }
    return false;
}

vector<string> docNames(vector<vector<DocumentItem > > search_res)
{
    vector<string> docs;
    for(int i=0;i<search_res.size();i++)
    {
        for(int j=0;j<search_res[i].size();j++)
        {
            if(!findInVec(docs,search_res[i][j].documentName))
            {
                docs.push_back(search_res[i][j].documentName);
            }
        }
    }
    return docs;
}

/*void perform_a_query(string query)
{
    istringstream iss(query);
    string str;
    vector<vector<DocumentItem> > search_results;
    vector<string>words;
    while(iss>>str)
    {
		ToLower(str);
		wordCheck(str);
        BstNode<string,WordItem> * search_res = tree.find(str);
        if(search_res !=NULL)
        {
            search_results.push_back(search_res->val.details);
            words.push_back(str);
        }
    }
    if(search_results.size()==0)
    {
        cout << "No document contains the given query" << endl;
    }
    else
    {
        vector<string> docs = docNames(search_results);
        for(int i=0;i<docs.size();i++)
        {
            cout << "in Document " << docs[i] ;
            for(int k=0;k<search_results.size();k++)
            {
                for(int t=0;t<search_results[k].size();t++)
                {
                    if(search_results[k][t].documentName == docs[i])
                    {
                        cout <<  ", " << words[k] << " found " << search_results[k][t].count << " times";
                    }
                }
            }
            cout << "." << endl;
        }
    }
}*/
 //end of reading the file

int main()
{
    int filecount;
	vector<string> final_bst;  
	vector<string> final_ht;  
	vector<string> bst_before; 
	vector<string> ht_before; 

    string filename,query;
    cout << "Enter the number of input files: ";
    cin >> filecount;
    for(int i=0;i<filecount;i++)
    {
        cout << "Enter " << i+1 << ". file name: ";
        cin >> filename;
        process_for_a_file(filename);
    }
    cout << "Enter queried words in one line: ";
    cin.ignore();
    cin.clear();
    getline(cin,query); 
    //perform_a_query(query);

	istringstream iss(query);
    string str;
    vector<vector<DocumentItem> > search_results;
    vector<string>words;
    while(iss>>str)
    {
		ToLower(str);
		bool check = (true && (word.length() != 0)); // word check
		for(unsigned int j=0; j< word.length(); j++) {
			if(!isalpha(word.at(j))) { 
				BstNode<string,WordItem> * search_res = tree.find(str);
				if(search_res ==NULL)
				{
					tree.insert(str); // add the word to the tree
					words.push_back(str);
				}
			
				if(search_results.size()==0)
				{
					cout << "No document contains the given query" << endl;
				}
				else
				{
					vector<string> docs = docNames(search_results);
					for(int i=0;i<docs.size();i++)
					{
						cout << "in Document " << docs[i] ;
						for(int k=0;k<search_results.size();k++)
						{
							for(int t=0;t<search_results[k].size();t++)
							{
								if(search_results[k][t].documentName == docs[i])
								{
									cout <<  ", " << words[k] << " found " << search_results[k][t].count << " times";
								}
							}
						}
						cout << "." << endl;
					}
				}
			}
		}
	}
	//BST QUERYING 
	auto start = std::chrono::high_resolution_clock::now();
	string res_ht, part, bst_word;
	for(int i = 0; i < bst_before.size(); i++)
	{
		BstNode<string,WordItem> * search_results = tree.find(bst_before[i]);
		bst_before[i] = bst_word;    //collect words in bst_before 
		for (int i = 0; i < bst_before.size(); i++)
		{
			bst_word = bst_before[i];
			if(bst_word.find(" ") != string::npos)
			{
				bool check = true;
				if(part.find(" ") == string::npos){
					check = false;
				}
				while(part.find(" ") != string::npos){
					ready = bst_word.substr(bst_word.rfind(" "));  // last word
					res_bst = res_bst + ready + " ";
					part = bst_word.substr(0, bst_word.rfind(" "));
				}
				if(check)
					final_bst[i] = res_bst;
				else
					final_bst[i] = part;
			}
			else
				final_bst[i] = bst_word;
		}
	}
	auto BSTTime = std::chrono::duration_cast<std::chrono::nanoseconds> 
							(std::chrono::high_resolution_clock::now() - start);
	cout << "\nTime: " << BSTTime.count() / bst_before.size() << "\n";

	start = std::chrono::high_resolution_clock::now();
	for (int i = 0; i < ht_before.size(); i++)
	{
		string ht_word = h_table.find(bst_before[i]);
		ht_before[i] = ht_word;
		for (int i = 0; i < ht_before.size(); i++)
		{
			string ht_word = ht_before[i];
			if(ht_word.find(" ") != string::npos)
			{
				bool check = true;
				if(part.find(" ") == string::npos){
					check = false;
				}
				while(part.find(" ") != string::npos){
					ready = bst_word.substr(bst_word.rfind(" "));  
					res_bst = res_bst + ready + " ";
					part = bst_word.substr(0, bst_word.rfind(" "));
				}
				if(check)
					final_ht[i] = res_ht;
				else
					final_ht[i] = part;
			}
			else
				final_ht[i] = ht_word;
		}
		auto HTTime = std::chrono::duration_cast<std::chrono::nanoseconds> 
							(std::chrono::high_resolution_clock::now() - start);
		cout << "\nTime: " << HTTime.count() / ht_before.size() << "\n";
		cout << "+ Speed up: " << BSTTime.count() / HTTime.count() << "x" << endl << endl;
    return 0;
}