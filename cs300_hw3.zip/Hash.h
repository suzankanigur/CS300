#ifndef HASH_H
#define HASH_H

#include <iostream>
#include <string>
#include "BST.h"

using namespace std;

template <class Type>
class HashNode
{
	public:
	Type key_word;
    Type value;
	HashNode * next;

	HashNode(): {}

	HashNode(const Type &v, const Type &k, HashNode*nt=NULL)
        : key_word(k), value(v), next(n) {}
};

//an initialization for ITEM_NOT_FOUND and an approximate initial size or default of 53

template <class Type>
class HashTable 
{
public:
	int getUnique(){
		return unique;
	}
	int getSize(){
		return size;
	}
	explicit HashTable(const Type & notFound, int size = 53);
	const Type & find(const Type & x) const; 
	void insert(const Type & key, const Type & value); 
private:
	int unique;
	int size;
	vector<HashNode<Type>*> hash_vector; //vector<HashNode> array;
	void rehash(); 
	const Type ITEM_NOT_FOUND;

};


unsigned long hashFunc(unsigned char *str)
{
	unsigned long hash = 5381;
    int c;
    while (c = *str++)
		hash = ((hash << 5) + hash) + c; 
	return hash;
}


//tests wheter positive number is prime or not.
bool isPrime(int n) 
{
	if(n == 2 || n == 3)
		return true;
	if(n == 1 || n % 2 == 0)
		return false;
	for(int i = 3; i*i <= n; i+=2)
		if(n % i == 0)
			return false;
	return true;
}

//assuming n is positive, returns a prime number at least at size of n.
int nextPrime(int n) 
{
	if(n % 2 == 0)
		n++;
	for(; !isPrime(n); n+=2)
		;
	return n;
}


//Constructing the hash table.
template <class Type>  
HashTable<Type>::HashTable(const Type & notFound, int size = 53): ITEM_NOT_FOUND(notFound), curSize(curSize), unique(0) 
{
	//makeEmpty
	hash_vector.resize(size);
	for(int i = 0; i < size; i++)
	{
		hash_vector[i] = NULL;
	}
}


template <class Type> 
const Type & hashtable<Type>::find(const Type & x) const
{
	int a = hashFunc(x, size); 
	HashNode<Type> * p = hash_vector[a];
	if(p == NULL)
		return ITEM_NOT_FOUND;
	while(p) //until zero
	{
		if(x == p->key_word)
			return p->value;
		p = p->next; //go till the end
	}
}


template <class Type> 
void hashtable<Type>::insert(const Type & key_word, const Type & value)
{
	int word = hashFunc(key_word, size);
	if(hash_vector[word] == NULL) //first occurance
	{
		unique++;
		hash_vector[word] = new hashnode<Type>(key_word, value); //create a new one
	}
	else // if exists
	{
		hashnode<Type> * p = hash_vector[index];
		bool check = true;
		while(p->next && check) //till find or the end 
		{
			if(p->key_word == key_word) // when found
			{
				p->value = p->value + ", " + value;
				check = false;
			}
			p = p->next;
		}
	}
	if ( ++size >= hash_vector.size( ) / 2 ) //load factor issue
		rehash( );
}


template <class Type>
void HashTable<Type>::rehash( ) 
{
	vector<HashEntry> oldArray = newArray; 

	// Create new double-sized, empty table
    newArray.resize( nextPrime( 2 * oldArray.size( ) ) );
    for ( int j = 0; j < newArray.size( ); j++ )
		newArray[ j ].info = EMPTY;

     // Copy table over
	size = 0;
	for ( int i = 0; i < oldArray.size( ); i++ )
		if ( oldArray[ i ].info == ACTIVE )
			insert( oldArray[ i ].element );
			
	double load_factor = double(unique)/double(size);
	cout << "rehashed...\n" << "previous table size: " << oldArray.size() << ", new table size: " << newArray.size() << " current unique word count " << unique << ", current load factor: " << load_factor << endl;
}
#endif
