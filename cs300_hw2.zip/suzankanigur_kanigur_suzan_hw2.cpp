#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "Avl.h"
#include <vector>
#include "strutils.h"
using namespace std;

AVLSearchTree<string,WordItem> bst;

bool isword(string word)
{
	for(int i=0;i<word.length();i++)
	{
		if(word[i]>='a' && word[i]<='z')
		{}
		else if(word[i]>='A' && word[i]<='Z')
		{}
		else
			return false;
	}
	return true;
}

void process_for_a_file(string filename)
{
    ifstream ifs;
    ifs.open(filename);
    string str;
    while(ifs>>str)
    {
		if(isword(str))
		{
			ToLower(str);
            bst.insert(str,filename);
		}
		
    }
    ifs.close();
}

bool findInVec(vector<string> vec, string key)
{
    for(int i=0;i<vec.size();i++)
    {
        if(vec[i]==key)
            return true;
    }
    return false;
}

vector<string> docNames(vector<vector<DocumentItem > > search_res)
{
    vector<string> docs;
    for(int i=0;i<search_res.size();i++)
    {
        for(int j=0;j<search_res[i].size();j++)
        {
            if(!findInVec(docs,search_res[i][j].documentName))
            {
                docs.push_back(search_res[i][j].documentName);
            }
        }
    }
    return docs;
}

void perform_a_query(string query)
{
    istringstream iss(query);
    string str;
    vector<vector<DocumentItem> > search_results;
    vector<string>words;
    while(iss>>str)
    {
		ToLower(str);
        AvlNode<string,WordItem> * search_res = bst.find(str);
        if(search_res !=NULL)
        {
            search_results.push_back(search_res->val.details);
            words.push_back(str);
        }
    }
    if(search_results.size()==0)
    {
        cout << "No document contains the given query" << endl;
    }
    else
    {
        vector<string> docs = docNames(search_results);
        for(int i=0;i<docs.size();i++)
        {
            cout << "in Document " << docs[i] ;
            for(int k=0;k<search_results.size();k++)
            {
                for(int t=0;t<search_results[k].size();t++)
                {
                    if(search_results[k][t].documentName == docs[i])
                    {
                        cout <<  ", " << words[k] << " found " << search_results[k][t].count << " times";
                    }
                }
            }
            cout << "." << endl;
        }
    }
    

}

int main()
{
    int filecount;
    string filename,query;
    cout << "Enter the number of input files: ";
    cin >> filecount;
    for(int i=0;i<filecount;i++)
    {
        cout << "Enter " << i+1 << ". file name: ";
        cin >> filename;
        process_for_a_file(filename);
    }
    cout << "Enter queried words in one line: ";
    cin.ignore();
    cin.clear();
    getline(cin,query); 
    perform_a_query(query);
    return 0;
}