#ifndef _AVL_H
#define _AVL_H
#include <string>
#include <iostream>
#include <vector>
using namespace std;

template <class Key, class Value>
class AVLSearchTree;

struct DocumentItem
{
    string documentName;
    int count;
    DocumentItem(string dN = "", int c = 0)
        : documentName(dN), count(c)
    {
    }
};
struct WordItem
{
    string word;
    vector<DocumentItem> details;
    WordItem()
    {
        word = "***not***found***";
    }
};

template <class Key, class Value>
class AvlNode
{
    public:
    Key key;
    Value val;
    AvlNode *left;
    AvlNode *right;
    int height;

    AvlNode(const Value &v, const Key &k, AvlNode *lt=NULL, AvlNode *rt=NULL, int h = 0)
        : key(k), val(v), left(lt), right(rt), height(h) {}

    friend class AVLSearchTree<Key, Value>;
};
template <class Key, class Value>
class AVLSearchTree
{
public:
    explicit AVLSearchTree()
        :root(NULL)
    {
    }

    AVLSearchTree(const AVLSearchTree &rhs)
        :root(NULL)
    {
        *this = rhs;
    }

    //~AVLSearchTree();

    bool isEmpty() const
    {
        return root==NULL;
    }
    bool isBalanced(int &left, int &right) const
    {
        left = height(root->left);
        right = height(root->right);
        int diff = abs(left - right);
        if (diff == 0 || diff == 1)
            return true;
        return false;
    }
    AvlNode<Key, Value>* find(Key &x)
    {
        return find(x, root);
    }
    void insert(Key &x, string dname)
    {
        insert(x,dname, root);
    }


private:
    AvlNode<Key, Value> *root;

 
    AvlNode<Key, Value> *find(Key &x, AvlNode<Key, Value> *t) const
    {
        
        while(t != NULL)
            if(x < t->key)
                t = t->left;
            else if(t->key < x)
                t = t->right;
            else
                return t;    // Match
        return NULL;   // No match
    }

    void insert(Key &x,string dname, AvlNode<Key,Value> *&t) const
    {
        WordItem w;
        w.word = x;
        w.details.push_back(DocumentItem(dname,1));
        if (t == NULL)
        {
            t = new AvlNode<Key,Value>(w,x);
        }
        else if (x < t->key)
        {
            // X should be inserted to the left tree!
            insert(x,dname, t->left);
            // Check if the left tree is out of balance (left subtree grew in height!)
            if (height(t->left) - height(t->right) == 2)
            {
                if (x < t->left->key)   // X was inserted to the left-left subtree!
                    rotateWithLeftChild(t);
                else                        // X was inserted to the left-right subtree!
                    doubleWithLeftChild(t);
            }
        }
        else if(t->key < x)
        {   // Otherwise X is inserted to the right subtree
            insert(x,dname, t->right);
            if (height(t->right) - height(t->left) == 2)
            {
                // height of the right subtree increased
                if (t->right->key < x)
                    // X was inserted to right-right subtree
                    rotateWithRightChild(t);
                else    // X was inserted to right-left subtree
                    doubleWithRightChild(t);
            }
        }
        else
        {
            bool ok = false;
            for(int i=0;i<t->val.details.size();i++)
            {
                if(t->val.details[i].documentName==dname)
                {
                    t->val.details[i].count++;
                    ok = true;
                }
            }
            if(!ok)
            {
                t->val.details.push_back(DocumentItem(dname,1));
            }
        }
        t->height = max(height(t->left), height(t->right)) + 1;
    }
    int height(AvlNode<Key, Value> *t) const
    {
        if (t == NULL)
            return -1;
        return t->height;
    }
    int max(int lhs, int rhs) const
    {
        if (lhs > rhs)
            return lhs;
        return rhs;
    }
    void rotateWithLeftChild(AvlNode<Key, Value> *&k2) const
    {
        AvlNode<Key,Value> *k1 = k2->left;
        k2->left = k1->right;
        k1->right = k2;
        k2->height = max(height(k2->left), height(k2->right)) + 1;
        k1->height = max(height(k1->left), k2->height) + 1;
        k2 = k1;
    }
    void rotateWithRightChild(AvlNode<Key, Value> *&k1) const
    {
        AvlNode<Key,Value> *k2 = k1->right;
        k1->right = k2->left;
        k2->left = k1;
        k1->height = max(height(k1->left), height(k1->right)) + 1;
        k2->height = max(height(k2->right), k1->height) + 1;
        k1 = k2;
    }
    void doubleWithLeftChild(AvlNode<Key, Value> *&k3) const
    {
        rotateWithRightChild(k3->left);
        rotateWithLeftChild(k3);
    }
    void doubleWithRightChild(AvlNode<Key, Value> *&k1) const
    {
        rotateWithLeftChild(k1->right);
        rotateWithRightChild(k1);
    }
};

#endif